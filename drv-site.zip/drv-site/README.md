# DRV Bund – Abteilungs-Informationsportal

Statische Webseite mit lokaler Datenspeicherung im Browser.
Kein Backend, kein Build-Schritt, keine Abhängigkeiten.

---

## Lokale Datenspeicherung – wichtig!

Alle Inhalte (Blog-Beiträge, Newsticker-Meldungen, Anzeigen am Schwarzen Brett)
werden im **LocalStorage des Browsers** gespeichert. Das bedeutet:

- ✅ Funktioniert ohne Internet, ohne Server, ohne Anmeldung
- ✅ Daten bleiben über Sitzungen hinweg erhalten
- ✅ Änderungen synchronisieren zwischen offenen Tabs desselben Browsers
- ⚠️ Daten sind **pro Browser und pro Gerät** – nicht über Nutzer geteilt
- ⚠️ Beim Leeren der Browserdaten oder im Inkognito-Modus gehen Inhalte verloren
- ⚠️ Speicherlimit: ca. 5–10 MB pro Domain

> Wenn alle Nutzer dieselben Inhalte sehen sollen, ist eine Backend-Lösung
> wie Firebase Firestore notwendig.

---

## Projektstruktur

```
drv-site/
├── README.md
└── public/
    ├── data-store.js          ⭐ LocalStorage-Abstraktion
    ├── logo.svg               ← Logo (austauschbar)
    ├── style.css              ← Gemeinsames Stylesheet
    ├── index.html             ← Startseite (Blog + Newsticker)
    ├── organigramm.html       ← Organigramm
    ├── schwarzes-brett.html   ← Schwarzes Brett
    └── admin.html             ← Verwaltung für Blog & Ticker
```

---

## Seiten

| Seite | URL | Funktion |
|---|---|---|
| Startseite | `index.html` | Blog-Feed (links) + Newsticker (rechte Sidebar) |
| Organigramm | `organigramm.html` | Statische Hierarchie-Darstellung |
| Schwarzes Brett | `schwarzes-brett.html` | Anzeigen lesen, filtern, erstellen |
| Admin | `admin.html` | Blog & Ticker pflegen + Datenverwaltung |

---

## Verwendung

Einfach `public/index.html` im Browser öffnen. Beim ersten Aufruf werden
Demo-Inhalte angelegt. Ab dann können Beiträge über die Admin-Seite und
Anzeigen direkt am Schwarzen Brett ergänzt werden.

### Auf einem Webserver hosten

Den `public/`-Ordner auf einen beliebigen statischen Webhost legen
(z.B. Nginx, Apache, GitHub Pages, Netlify, Vercel, Firebase Hosting).
Es sind keine serverseitigen Funktionen erforderlich.

### Lokal mit Mini-Webserver testen

```bash
# Python
cd public && python3 -m http.server 8000

# Node.js
npx serve public
```

Dann `http://localhost:8000` öffnen.

---

## Logo austauschen

Das Logo liegt unter `public/logo.svg` und wird von allen Seiten eingebunden.

**Variante A – einfach ersetzen:** Eigene Datei unter `public/logo.svg` ablegen.

**Variante B – anderen Dateinamen nutzen:** z.&thinsp;B. `public/mein-logo.png`,
dann in den vier HTML-Dateien das `src`-Attribut anpassen:

```html
<img class="logo-image" src="mein-logo.png" alt="DRV Bund Logo">
```

Größe: per CSS auf 44 px Höhe skaliert (max. 240 px breit). Bei dunklen Logos
in `style.css` den weißen Hintergrund-Pad bei `.logo-image` einkommentieren.

---

## Datenverwaltung

Auf der Admin-Seite gibt es unten den Bereich „Datenverwaltung":

- **Auf Demo-Inhalte zurücksetzen** – überschreibt alle aktuellen Daten
  mit den ursprünglichen Beispielinhalten
- **Alle Daten löschen** – entfernt sämtliche Inhalte aus dem LocalStorage

---

## Datenstruktur

Im LocalStorage werden vier Schlüssel verwendet:

| Schlüssel | Inhalt |
|---|---|
| `drv_blog_posts` | JSON-Array mit Blog-Beiträgen |
| `drv_news_ticker` | JSON-Array mit Ticker-Meldungen |
| `drv_schwarzes_brett` | JSON-Array mit Anzeigen |
| `drv_seeded_v1` | Flag: Wurde Demo-Seed bereits eingespielt? |

Jeder Eintrag hat mindestens die Felder `id`, `createdAt` (ISO-Datum) und
die jeweiligen inhaltlichen Felder (z.&thinsp;B. `title`, `text`, `author`).

---

## Farben

| Token | Hex | Verwendung |
|---|---|---|
| Navy | `#073163` | Header, Texte, primäre Akzente |
| Lime | `#D3DB2B` | Highlights, Buttons, aktive Nav |
| Ice | `#E1E6EC` | Hintergründe, Badges, Sidebar |
